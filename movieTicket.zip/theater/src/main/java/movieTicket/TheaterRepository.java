package movieTicket;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface TheaterRepository extends PagingAndSortingRepository<Theater, Long>{


}