package movieTicket;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface NotificationHistoryRepository extends PagingAndSortingRepository<NotificationHistory, Long>{


}